#include <iostream>
# include "Stack.h"
# include "Queue.h"
using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}





