#include "astack.h"

astack::astack()
{
    //ctor
}

astack::~astack()
{
    //dtor
}
