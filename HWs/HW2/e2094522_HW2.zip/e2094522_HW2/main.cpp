#include <iostream>

#include "./include/link.h"
#include "./include/node.h"
#include "./include/PQ.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;


    LinkedList<int> Halil;


    Halil.InsertFront(2);
    Halil.InsertFront(0);
        Halil.InsertRear(1);
    Halil.InsertRear(3);
    Halil.InsertAt(4);
//    Halil.InsertFront(8);
//        Halil.InsertFront(1);
//    Halil.InsertFront(5);
    Halil.PrintList();
    return 0;


}


