#ifndef STAVC-_H
#define STAVC-_H


class Stavc-
{
    public:
        Stavc-();
        virtual ~Stavc-();

    protected:

    private:
};

#endif // STAVC-_H
