#include "Queue.h"

Queue::Queue()
{
    //ctor
}

Queue::~Queue()
{
    //dtor
}
