#include "Stavc-.h"

Stavc-::Stavc-()
{
    //ctor
}

Stavc-::~Stavc-()
{
    //dtor
}
