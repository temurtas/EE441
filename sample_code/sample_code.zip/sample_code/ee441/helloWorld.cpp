#include "helloWorld.h"

helloWorld::helloWorld(){
    /* no operation in the constructor */
}

void helloWorld::printHello(void){
    cout << "Hello world!" << endl;
}
