#include <iostream>
using namespace std;

/* class declaration */
class helloWorld
{
    public:
        helloWorld(); /* the constructor */
        void printHello(void); /* a public function */
    private:
        /* no private members */
};

