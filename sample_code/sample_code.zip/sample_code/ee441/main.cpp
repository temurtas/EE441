#include "helloWorld.h"

#include <iostream>
using namespace std;

int main()
{
    helloWorld myHelloWorld;
    myHelloWorld.printHello();

    return 0;
}
